import com.khidmeti.LocationForegroundService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON" -> {
                // Démarrer l'application au boot
                restartApp(context)
            }
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_PACKAGE_REPLACED -> {
                // Redémarrer après mise à jour
                if (intent.dataString?.contains(context.packageName) == true) {
                    restartApp(context)
                }
            }
        }
    }
    
    private fun restartApp(context: Context) {
        val sharedPref = context.getSharedPreferences("khidmeti_prefs", Context.MODE_PRIVATE)
        val isWorkerLoggedIn = sharedPref.getBoolean("is_worker_logged_in", false)
        val isLocationServiceEnabled = sharedPref.getBoolean("location_service_enabled", false)
        
        // Démarrer l'app principale
        val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
        launchIntent?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            context.startActivity(it)
        }
        
        // Démarrer le service de localisation si nécessaire
        if (isWorkerLoggedIn && isLocationServiceEnabled) {
            val serviceIntent = Intent(context, LocationForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}