package com.khidmeti
import androidx.core.content.ContextCompat
import android.app.*
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        // Traiter les données du message
        val title = remoteMessage.notification?.title ?: "Khidmeti"
        val body = remoteMessage.notification?.body ?: "Nouveau message"
        val data = remoteMessage.data

        // Déterminer le type de notification
        val notificationType = data["type"] ?: "general"
        val channelId = when (notificationType) {
            "chat" -> "khidmeti_chat"
            "request" -> "khidmeti_requests"
            "location" -> "khidmeti_location"
            else -> "khidmeti_general"
        }

        // Afficher la notification
        showNotification(title, body, channelId, data)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        
        // Envoyer le token à Flutter via MethodChannel ou le sauvegarder
        sendTokenToFlutter(token)
    }

    private fun showNotification(title: String, body: String, channelId: String, data: Map<String, String>) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            // Ajouter les données pour navigation
            data.forEach { (key, value) ->
                putExtra(key, value)
            }
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL)

        // Personnaliser selon le type
        when (channelId) {
            "khidmeti_chat" -> {
                notificationBuilder.setColor(ContextCompat.getColor(this, R.color.khidmeti_accent))
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_MESSAGE)
            }
            "khidmeti_requests" -> {
                notificationBuilder.setColor(ContextCompat.getColor(this, R.color.khidmeti_primary))
                notificationBuilder.setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            }
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(System.currentTimeMillis().toInt(), notificationBuilder.build())
    }

    private fun sendTokenToFlutter(token: String) {
        // Sauvegarder le token localement pour l'envoyer à Flutter
        val sharedPref = getSharedPreferences("khidmeti_prefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putString("fcm_token", token)
            apply()
        }
    }
}
