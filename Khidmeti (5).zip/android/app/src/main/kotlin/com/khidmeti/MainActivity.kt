package com.khidmeti

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.TimeUnit

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.khidmeti/native"
    private val PERMISSION_REQUEST_CODE = 1001
    private val LOCATION_REQUEST_CODE = 1002
    
    private val requiredPermissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_BACKGROUND_LOCATION,
        Manifest.permission.CAMERA,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.WAKE_LOCK,
        Manifest.permission.RECEIVE_BOOT_COMPLETED,
        Manifest.permission.FOREGROUND_SERVICE,
        Manifest.permission.FOREGROUND_SERVICE_LOCATION,
        Manifest.permission.POST_NOTIFICATIONS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Créer les canaux de notification
        createNotificationChannels()
        
        // Demander les permissions
        requestPermissions()
        
        // Initialiser WorkManager pour les tâches en arrière-plan
        initializeWorkManager()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "requestPermissions" -> {
                    requestPermissions()
                    result.success(true)
                }
                "startLocationService" -> {
                    startLocationBackgroundService()
                    result.success(true)
                }
                "stopLocationService" -> {
                    stopLocationBackgroundService()
                    result.success(true)
                }
                "checkLocationSettings" -> {
                    val isEnabled = isLocationEnabled()
                    result.success(isEnabled)
                }
                "openLocationSettings" -> {
                    openLocationSettings()
                    result.success(true)
                }
                "isAppOptimizationDisabled" -> {
                    val isDisabled = isAppOptimizationDisabled()
                    result.success(isDisabled)
                }
                "requestDisableOptimization" -> {
                    requestDisableOptimization()
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // Canal pour les notifications générales
            val generalChannel = NotificationChannel(
                "khidmeti_general",
                "Notifications Générales",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications générales de Khidmeti"
                enableVibration(true)
                enableLights(true)
            }
            
            // Canal pour les messages
            val chatChannel = NotificationChannel(
                "khidmeti_chat",
                "Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications de messages"
                enableVibration(true)
                enableLights(true)
            }
            
            // Canal pour le service de localisation
            val locationChannel = NotificationChannel(
                "khidmeti_location",
                "Service de Localisation",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Service de localisation en arrière-plan"
                enableVibration(false)
                enableLights(false)
            }
            
            // Canal pour les demandes de service
            val requestChannel = NotificationChannel(
                "khidmeti_requests",
                "Demandes de Service",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Nouvelles demandes de service"
                enableVibration(true)
                enableLights(true)
            }
            
            notificationManager.createNotificationChannels(listOf(
                generalChannel, chatChannel, locationChannel, requestChannel
            ))
        }
    }

    private fun requestPermissions() {
        val missingPermissions = requiredPermissions.filter { permission ->
            ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED
        }
        
        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                missingPermissions.toTypedArray(),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                val deniedPermissions = permissions.filterIndexed { index, _ ->
                    grantResults[index] != PackageManager.PERMISSION_GRANTED
                }
                
                if (deniedPermissions.isNotEmpty()) {
                    Toast.makeText(
                        this,
                        "Certaines permissions sont nécessaires pour le bon fonctionnement de l'application",
                        Toast.LENGTH_LONG
                    ).show()
                    
                    // Demander à nouveau les permissions critiques
                    if (deniedPermissions.contains(Manifest.permission.ACCESS_FINE_LOCATION) ||
                        deniedPermissions.contains(Manifest.permission.CAMERA)) {
                        requestPermissions()
                    }
                } else {
                    Toast.makeText(this, "Permissions accordées", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun initializeWorkManager() {
        val configuration = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
        
        WorkManager.initialize(this, configuration)
    }

    private fun startLocationBackgroundService() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .setRequiresBatteryNotLow(false)
            .build()

        val locationWork = PeriodicWorkRequestBuilder<LocationWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .setBackoffCriteria(
                BackoffPolicy.LINEAR,
                WorkRequest.MIN_BACKOFF_MILLIS,
                TimeUnit.MILLISECONDS
            )
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "location_tracking",
            ExistingPeriodicWorkPolicy.REPLACE,
            locationWork
        )
    }

    private fun stopLocationBackgroundService() {
        WorkManager.getInstance(this).cancelUniqueWork("location_tracking")
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    private fun openLocationSettings() {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        startActivityForResult(intent, LOCATION_REQUEST_CODE)
    }

    private fun isAppOptimizationDisabled(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            powerManager.isIgnoringBatteryOptimizations(packageName)
        } else {
            true
        }
    }

    private fun requestDisableOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = android.net.Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        
        // Vérifier si les services de localisation sont activés
        if (!isLocationEnabled()) {
            Toast.makeText(
                this,
                "Veuillez activer les services de localisation",
                Toast.LENGTH_LONG
            ).show()
        }
        
        // Vérifier l'optimisation de la batterie
        if (!isAppOptimizationDisabled()) {
            Toast.makeText(
                this,
                "Désactivez l'optimisation de la batterie pour un meilleur fonctionnement",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

// Worker pour la géolocalisation en arrière-plan
class LocationWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    
    override fun doWork(): Result {
        return try {
            // Logique de mise à jour de la localisation
            updateLocationInFirebase()
            Result.success()
        } catch (exception: Exception) {
            Result.retry()
        }
    }
    
    private fun updateLocationInFirebase() {
        // Cette méthode sera appelée par Flutter via MethodChannel
        // ou implémentée directement en Kotlin si nécessaire
    }
}